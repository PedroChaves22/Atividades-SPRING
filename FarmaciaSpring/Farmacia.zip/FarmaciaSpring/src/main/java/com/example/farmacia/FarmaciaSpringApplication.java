package com.example.farmacia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmaciaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmaciaSpringApplication.class, args);
	}

}
