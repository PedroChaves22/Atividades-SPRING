package com.lojagames.model;

public class Produto {

}
