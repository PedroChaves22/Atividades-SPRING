package com.lojagames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
